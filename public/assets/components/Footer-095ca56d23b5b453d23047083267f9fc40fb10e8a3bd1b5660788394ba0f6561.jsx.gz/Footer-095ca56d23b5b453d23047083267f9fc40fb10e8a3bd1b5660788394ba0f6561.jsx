class Footer extends React.Component {

  render() {
    return(
        <footer className="footer">
        <hr/>
          <ul className="footer-bar">
            <li> &#169;2016 Framework</li>
            <li><a href="mailto:someone@example.com">Contact Us</a></li>
            <li><a href="/">Careers</a></li>
            <li><a href="/">About</a></li>
            <li><a href="/">Help</a></li>
            <li><a href="/">Site Map</a></li>
          </ul>
        </footer>
    )
  }
}
