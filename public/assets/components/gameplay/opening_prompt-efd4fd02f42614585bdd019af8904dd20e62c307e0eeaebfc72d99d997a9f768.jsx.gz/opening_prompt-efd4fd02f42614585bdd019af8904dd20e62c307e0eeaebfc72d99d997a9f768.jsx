class OpeningPrompt extends React.Component {
  render() {
    return(
      <div id="openingPrompt" > Locate the word parts! </div>
    )
  }
}
